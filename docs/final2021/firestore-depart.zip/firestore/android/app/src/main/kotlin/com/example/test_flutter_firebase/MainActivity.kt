package com.example.test_flutter_firebase

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
