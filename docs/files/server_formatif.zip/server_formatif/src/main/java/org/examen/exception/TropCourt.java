package org.examen.exception;

public class TropCourt extends Exception {
}
