package org.examen.transfer;

import java.util.Date;

public class Requete {

    public String nom;

}
