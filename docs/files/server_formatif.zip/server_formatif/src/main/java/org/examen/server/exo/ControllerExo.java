package org.examen.server.exo;

import org.examen.exception.TropCourt;
import org.examen.server.ConfigHTTP;
import org.examen.transfer.Requete;
import org.kickmyb.transfer.AddTaskRequest;
import org.kickmyb.transfer.HomeItemResponse;
import org.kickmyb.transfer.TaskDetailResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

// This is JAX-RS Jersey style annotations
// Can be mixed with Spring Security security
// And can used Autowired Services too
@Controller
public class ControllerExo {

	/**
	 * Tester votre serveur
	 * @return
	 */
	@GetMapping("/test")
	public @ResponseBody String test() {
		return "SALUT";
	}

	@PostMapping("/exos/error/or/not/")
	public @ResponseBody String errorOrNot(@RequestBody Requete req) throws TropCourt {

		if (req.nom.length() < 5) throw new TropCourt();

		return"Yeah!!!";

	}


}
