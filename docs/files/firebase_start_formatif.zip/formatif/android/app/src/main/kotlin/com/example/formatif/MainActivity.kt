package com.example.formatif

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
